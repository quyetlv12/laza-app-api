<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\quyet-dev\laravel\laza-api-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>