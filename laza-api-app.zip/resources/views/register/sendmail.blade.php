<x-mail::message>
Bạn đã đăng kí tài khoản thành công
<x-mail::button :url="''">
Đăng nhập ngay
</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
